﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_19
{
    public class PartTimeEmployee : Employee
    {
        public PartTimeEmployee(string name) : base(name, 20)
        {

        }
    }
}
