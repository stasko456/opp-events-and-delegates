﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_19
{
    public class StandartEmployee : Employee
    {
        public StandartEmployee(string name) : base(name, 40)
        {
        }
    }
}
