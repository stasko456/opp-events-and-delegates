﻿using project_19;

class Program
{
    public static void Main(string[] argms)
    {
        List<Job> jobs = new List<Job>();
        List<Employee> employees = new List<Employee>();

        string[] input = Console.ReadLine().Split(' ').ToArray();
        while (input[0] != "End")
        {
            switch (input[0])
            {
                case "Job":
                    Employee employee = employees.Where(x => x.Name == input[3]).FirstOrDefault();
                    if (employee != null)
                    {
                        if (!employees.Contains(employee))
                        {
                            employees.Add(employee);
                        }
                        else
                        {
                            throw new ArgumentException("The employee is already added to the collection!");
                        }
                    }
                    else
                    {
                        throw new ArgumentException("The employee is null!");
                    }
                    Job job = new Job(input[1], int.Parse(input[2]), employee);
                    if (job != null)
                    {
                        if (!jobs.Contains(job))
                        {
                            jobs.Add(job);
                        }
                        else
                        {
                            throw new ArgumentException("The job is already added to the collection!");
                        }
                    }
                    else
                    {
                        throw new ArgumentException("The job is null!");
                    }
                    break;
                case "StandartEmployee":
                    Employee employee1 = new StandartEmployee(input[1]);
                    if (employee1 != null)
                    {
                        if (!employees.Contains(employee1))
                        {
                            employees.Add(employee1);
                        }
                        else
                        {
                            throw new ArgumentException("The employee is already added to the collection!");
                        }
                    }
                    else
                    {
                        throw new ArgumentException("The employee is null!");
                    }
                    break;
                case "PartTimeEmployee":
                    Employee employee2 = new PartTimeEmployee(input[1]);
                    if (employee2 != null)
                    {
                        if (!employees.Contains(employee2))
                        {
                            employees.Add(employee2);
                        }
                        else
                        {
                            throw new ArgumentException("The employee is already added to the collection!");
                        }
                    }
                    else
                    {
                        throw new ArgumentException("The employee is null!");
                    }
                    break;
                case "Pass Week":
                    foreach (Job job1 in jobs)
                    {
                        foreach (Employee employee3 in employees)
                        {
                            job1.Update(employee3);
                        }
                    }
                    break;
                case "Status":
                    foreach (Job job1 in jobs)
                    {
                        Console.WriteLine($"Job: {job1.Name}, Hours Remaining:{job1.RequiredHours}");
                    }
                    break;
                default:
                    break;
            }
        }
    }
}