﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_19
{
	public delegate void JobPerformed();

    public class Job
    {
		private string name;
		private int requiredHours;
		private Employee employee;

		public event JobPerformed OnJobPerformed;

		public Employee Employee
		{
			get { return this.employee; }
			set { this.employee = value; }
		}

		public int RequiredHours
        {
			get { return this.requiredHours; }
			set { this.requiredHours = value; }
		}

		public string Name
		{
			get { return this.name; }
			set 
			{
				if (string.IsNullOrEmpty(value))
				{
					throw new ArgumentException("The name of the job cannot be null or empty!");
				}
				else
				{
                    this.name = value;
                } 
			}
		}

        public Job(string name, int requiredHours, Employee employee)
        {
            this.Name = name;
			this.RequiredHours = requiredHours;
			this.Employee = employee;
        }

		public void Update(Employee employee)
		{
            this.RequiredHours = this.RequiredHours - employee.WorkHours;

			if (this.RequiredHours <= 0)
			{
                Console.WriteLine($"Job {this.Name} done!");
				if (this.OnJobPerformed != null)
				{
					OnJobPerformed();
				}
			}
		}
    }
}
