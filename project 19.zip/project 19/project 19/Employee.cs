﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_19
{
    public class Employee
    {
        private string name;
        private int workHours;

        public int WorkHours
        {
            get { return this.workHours; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("The wotk hours of the employee cannot be zero or bellow!");
                }
                else
                {
                    this.workHours = value;
                }
            }
        }

        public string Name
        {
            get { return this.name; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The employee's name cannot be null ro empty!");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        public Employee(string name, int workHours)
        {
            this.Name = name;
            this.WorkHours = workHours;
        }
    }
}
