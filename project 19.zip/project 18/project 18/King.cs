﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_18
{
    public delegate void AttackEventHandler();

    public class King
    {
		private string name;
		public event AttackEventHandler OnAttack;

		public string Name
		{
			get { return this.name; }
			set 
			{
				if (string.IsNullOrEmpty(value))
				{
					throw new ArgumentException("The king's name cannot be null or empty!");
				}
				else
				{
                    this.name = value;
                } 
			}
		}

		public void Attack()
		{
            Console.WriteLine($"King {this.Name} is under attack!");
			if (OnAttack != null)
			{
				OnAttack();
			}

		}

        public King(string name)
        {
			this.Name = name;
        }
    }
}
