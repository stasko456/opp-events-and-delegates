﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_18
{
    public class RoyalGuard
    {
        private string name;

        public string Name
        {
            get { return this.name; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The royal guard's name cannot be null or empty!");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        public void RespondToAttack()
        {
            Console.WriteLine($"Royal Guard {this.Name} is defending!");
        }

        public RoyalGuard(string name)
        {
            this.Name = name;
        }
    }
}
