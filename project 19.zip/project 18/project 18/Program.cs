﻿using project_18;
using System;
using System.ComponentModel;

class Program
{
    public static void Main(string[] argms)
    {
        Dictionary<string, RoyalGuard> guards = new Dictionary<string, RoyalGuard>();
        Dictionary<string, Footman> footmans = new Dictionary<string, Footman>();

        Console.Write("Enter the king's name:");
        string kingName = Console.ReadLine();
        Console.WriteLine("----------------------");
        Console.WriteLine("Enter the royal guards'names: ");
        string[] royalGuardsNames = Console.ReadLine().Split(' ').ToArray();
        Console.WriteLine("----------------------");
        Console.WriteLine("Enter the footmans'names: ");
        string[] footmansNames = Console.ReadLine().Split(' ').ToArray();
        Console.WriteLine("----------------------");

        Console.WriteLine("Commands: ");
        Console.WriteLine("1. Attack King;");
        Console.WriteLine("2. Kill {footman or royal guard's name has to be entered};");
        Console.WriteLine("3. End to stop the programm!");
        Console.WriteLine("----------------------");

        King king = new King(kingName);

        foreach (string guardName in royalGuardsNames)
        {
            if (!guards.ContainsKey(guardName))
            {
                RoyalGuard royalGuard = new RoyalGuard(guardName);
                guards[guardName] = royalGuard;
                king.OnAttack += royalGuard.RespondToAttack;
            }
        }

        foreach (string footmanName in footmansNames)
        {
            if (!footmans.ContainsKey(footmanName))
            {
                Footman footman = new Footman(footmanName);
                footmans[footmanName] = footman;
                king.OnAttack += footman.RespondToAttack;
            }
        }

        string[] input = Console.ReadLine().Split(',').ToArray();
        while (input[0] != "End")
        {
            switch (input[0])
            {
                case "Attack King":
                    king.Attack();
                    break;
                case "Kill":
                    if (footmans.ContainsKey(input[1]))
                    {
                        king.OnAttack -= footmans[input[1]].RespondToAttack;
                        footmans.Remove(input[1]);
                    }
                    else if (guards.ContainsKey(input[1]))
                    {
                        king.OnAttack -= guards[input[1]].RespondToAttack;
                        guards.Remove(input[1]);
                    }
                    break;
                default:
                    break;
            }
            input = Console.ReadLine().Split(',').ToArray();
        }
    }
}